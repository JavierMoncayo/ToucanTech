<?php

class Javi_Model extends CI_Model
{

  /**
   * 
   * @param string $condition Condition to select members from DB
   * @return stdClass 
   */
  public function getMembers ($condition)
  {
    $sql = "SELECT members.name, email, schools.id, schools.name AS schoolName
            FROM members
            JOIN schools ON ( members.id_school = schools.id)
            $condition
            ORDER BY members.id";
    return $this->db->query ($sql)->result ();
  }

  /**
   * 
   * @param string $name Name of the new member to add.
   * @param string $email Email address of the new member.
   * @param string $school School name.
   */
  public function addMember ($name, $email, $school)
  {
    $idSchool = $this->getSchoolId ($school);
    $sql = "INSERT INTO members (name, email, id_school)
            VALUES ('$name', '$email','$idSchool->id')";
    $this->db->query ($sql);
  }

  /**
   * 
   * @return stdClass 
   */
  public function getSchools ()
  {
    $sql = "SELECT id, name FROM schools";
    return $this->db->query ($sql)->result ();
  }

  /**
   * 
   * @param string $name Name of the school to get the id in DB.
   * @return type
   */
  public function getSchoolId ($name)
  {
    $sql = "SELECT id FROM schools WHERE name = '$name'";
    return $this->db->query ($sql)->row ();
  }

}
