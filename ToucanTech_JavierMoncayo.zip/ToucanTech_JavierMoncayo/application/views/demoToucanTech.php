<script>
//#################################################################
//  Add new members into DB using AJAX.
//#################################################################
  function addMember(name, email, school)
  {
      mName = document.getElementById(name).value;
      mEmail = document.getElementById(email).value;
      nSchool = document.getElementById(school).value;

      $.ajax({
          type: 'POST',
          url: '/exp/index.php/Javi_Controller/addMember/' + mName + '/' + mEmail + '/' + nSchool, //the method in controller
          success: function (resp)
          {
              $('#memberList').html(resp)
          }
      });
  }
//#################################################################
//            Little form to add new members into de DB.
//#################################################################
  function seeSchool() {
      nSchool = document.getElementById("selectSchool").value;

      $.ajax({
          type: 'POST',
          url: '/exp/index.php/Javi_Controller/seeSchool/' + nSchool,
          success: function (resp)
          {
              $('#schoolDetails').html(resp)
          }
      });
  }
</script>
<body>
    <div id="accordion">
        <h3>Add new member</h3>
        <div>
            <!-- #################################################################
            Little form to add new members into de DB.
            ###################################################################-->
            <div id="left">
                <input id="name" type="text" size="32" placeholder="Member name" onfocus="infiniteLoop()"
                       style="margin-bottom:10px">
                <input id="email" type="text" size="32" placeholder="Member email"
                       style="margin-bottom:10px">
                <input id='school' list="schools" name="schools" size="32" placeholder="Select a school" 
                       style="margin-bottom:10px">
                <datalist id="schools">
                    <?php foreach ($schools as $current): ?>
                      <option value="<?php echo $current->name; ?>">
                        <?php endforeach; ?>
                </datalist><br>
                <input type="button" value ="Add new" onclick="addMember('name', 'email', 'school')"
                       style="margin-bottom:10px">
            </div>
            <!-- #################################################################
            This <div> will be updated each time a member is add to the DB.
            ###################################################################-->
            <div id="memberList" class="right">
                <table border="0">
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>School name</th>
                    </tr>
                    <tbody>
                        <?php foreach ($members as $current): ?>
                          <tr>
                              <td><?php echo $current->name ?></td>
                              <td><?php echo $current->email ?></td>
                              <td><?php echo $current->schoolName ?></td>
                          </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <h3>See members of one school</h3>
        <div>
            <!-- #################################################################
                List to select a school to see members.
            ###################################################################-->
            <div id="left">
                <input id='selectSchool' list="schools" name="schools" size="32" placeholder="Select a school" 
                       style="margin-bottom:10px" onchange="seeSchool()">
                <datalist id="schools">
                    <?php foreach ($schools as $current): ?>
                      <option value="<?php echo $current->name; ?>">
                        <?php endforeach; ?>
                </datalist><br>
                <input type="button" value ="See details">
            </div>
            <!-- #####################################1############################
            This <div> will be updated when a school is selected by AJAX.
            ###################################################################-->
            <div id="schoolDetails" class="right">
            </div>
        </div>
    </div>
    <script>
      $("#accordion").accordion();
    </script>   