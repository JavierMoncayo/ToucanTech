<table border="0">
    <thead>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>School name</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($members as $current): ?>
          <tr>
              <td><?php echo $current->name ?></td>
              <td><?php echo $current->email ?></td>
              <td><?php echo $current->schoolName ?></td>
          </tr>
        <?php endforeach; ?>
    </tbody>
</table>