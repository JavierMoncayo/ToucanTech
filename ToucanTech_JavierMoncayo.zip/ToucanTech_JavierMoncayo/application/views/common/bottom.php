<div id="solid">
    <p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds.
        <br>
        Javier Moncayo.
    </p>
</div>
</body>
</html>