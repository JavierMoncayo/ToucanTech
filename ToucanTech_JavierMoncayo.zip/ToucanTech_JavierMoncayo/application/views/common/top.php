<html>
    <head>
        <title>Javier Moncayo demo.</title>
        <link href="<?php echo $this->config->item ('base_url') ?>/exp/assets/jquery-ui/jquery-ui.css" rel="stylesheet">
        <script src="<?php echo $this->config->item ('base_url') ?>/exp/assets/jquery-ui/external/jquery/jquery.js"></script>
        <script src="<?php echo $this->config->item ('base_url') ?>/exp/assets/jquery-ui/jquery-ui.js"></script>
        <script src="external/jquery/jquery.js"></script>
        <link rel="stylesheet" type="text/css" href="<?php echo $this->config->item ('base_url') ?>/exp/assets/MyCSS/Main.css">
        <style>
            body{
                font-family: "Trebuchet MS", sans-serif;
                margin: 50px;
            }
            .demoHeaders {
                margin-top: 2em;
            }
            #dialog-link {
                padding: .4em 1em .4em 20px;
                text-decoration: none;
                position: relative;
            }
            #dialog-link span.ui-icon {
                margin: 0 5px 0 0;
                position: absolute;
                left: .2em;
                top: 50%;
                margin-top: -8px;
            }
            #icons {
                margin: 0;
                padding: 0;
            }
            #icons li {
                margin: 2px;
                position: relative;
                padding: 4px 0;
                cursor: pointer;
                float: left;
                list-style: none;
            }
            #icons span.ui-icon {
                float: left;
                margin: 0 4px;
            }
            .fakewindowcontain .ui-widget-overlay {
                position: absolute;
            }
            select {
                width: 200px;
            }
        </style>
    </head>
    <body>
        <div id ="title">Welcome to ToucanTech demo by <strong>Javier Moncayo</strong></div>
        <div id='cssmenu'>
            <ul>        
                <li class='active'>
                </li>
            </ul>
        </div>