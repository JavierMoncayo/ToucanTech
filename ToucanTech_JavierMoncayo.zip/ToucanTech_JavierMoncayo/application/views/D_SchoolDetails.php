<div class="rigth">
    <table border="0">
        <thead>
        <caption><?php $schoolName ?></caption>
        <tr>
            <th>Name</th>
            <th>Email</th>
        </tr>
        </thead>
        <tbody>
            <?php foreach ($members as $current): ?>
              <tr>
                  <td><?php echo $current->name ?></td>
                  <td><?php echo $current->email ?></td>
              </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>