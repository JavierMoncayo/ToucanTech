<?php

defined ('BASEPATH') OR exit ('No direct script access allowed');

class Javi_Controller extends CI_Controller
{

  public $Data;

  public function __construct ()
  {
    parent::__construct ();
    $this->load->helper ('url');
    $this->load->database ();

    $this->load->model ('Javi_Model');
    $this->Data = new Javi_Model();
  }

  public function index ()
  {
    $output['members'] = $this->getMembers ('');
    $output['schools'] = $this->getSchools ();
    $this->load->view ('common/top');
    $this->load->view ('demoToucanTech', $output);
    $this->load->view ('common/bottom');
  }

  public function getMembers ($condition)
  {
    return $this->Data->getMembers ($condition);
  }

  public function getSchools ()
  {
    return $this->Data->getSchools ();
  }

  /** ###############################################################
   *  AJAX methods in the controller.
    ############################################################### */
  public function addMember ($name, $email, $school)
  {
    $this->Data->addMember ($name, $email, $school);
    $output['members'] = $this->getMembers ('');
    $this->load->view ('D_MemberList', $output);
  }

  public function seeSchool ($school)
  {
    $idSchool = $this->Data->getSchoolId ($school);
    $condition = "WHERE schools.id =" . $idSchool->id;

    $output['members'] = $this->getMembers ($condition);
    $output['schoolName'] = $school;
    $this->load->view ('D_SchoolDetails', $output);
  }

}
